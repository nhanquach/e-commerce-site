=== FB Comment and Share For WooCommerce ===
Contributors: TheAnuvhuti, themexpand, extraperson
Donate link: https://www.shameemreza.com/coffee
Plugin Name: FB Comment and Share For WooCommerce
Plugin URI: https://wordpress.org/plugins/fb-comment-share-for-woocommerce/
Tags: comments, woocommerce, Facebook, share
Author URI: http://themexpand.net/
Author: Shameem Reza
Requires at least: 3.0.1
Tested up to: 4.5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add facebook comment and share on your woocommerce product page

== Description ==

Facebook Commenter and Share allow you integrate woocommerce reviewing and commenting system through facebook.

> Download No 1 WordPress Admin Template : [WP Expand](http://themexpand.com/product/wpexpand/ "Customize WordPress Admin as a complete CMS for Your Clients.")

Allow your customer give you review/comment from their facebook account. It also integrated with social share, so you and your customer can share your woocommerce product to your/their facebook timeline easy. So lets share/and be reviewed product through face book and other socialmedia.


== Installation ==

Installing FB Comment & Share For WooCommerce requires little modification code, no theme modification, and installs as easy as any other plugin.

 1.You can use wordpress plugin uploader to automaticly install this plugin -OR
 
 2.Upload the woocommerce-fb-comment folder to your WordPress plugin directory. ( wp-content/plugins )
 
 3.Activate the plugin from your WordPress plugin administration page
 
 4.You can now go the Woocommerce -> FBC Settings page to configure it!

<h3>Setting up your Plugin </h3>

To setting your plugin you must login to your admin dashboard.

 1.Login to your admin dashboard
 
 2.Go to Woocommerce -> FBC Settings
 
 3.Them you can see setup form
 
 4.Fill/change value above suitable with your detail
 
 5.Save it!

Enjoy

> More Themes and Plugins that work: [ThemeXpand](http://themexpand.com/ "Premium WordPress Themes")

== Screenshots ==
1. FBC Setting (Main)
2. Product Page Setting

== Changelog ==

= 1.5.0 =
Color swiping option problem solve.

= 1.5.1 =
Intial Release
Compitable to work with wordpress 4.2.1
Compitable with Woocommerce 2.3+

= 1.5.2 =
Compatiable with WordPress 4.4
Support Latest Facebook API
Improved Performance
and Fixes some Bug